// Mobile menu toggle
document.getElementById("menu-toggle").addEventListener("click", function() {
  document.getElementById("menu").classList.toggle("show");
});

// Donation box function
function makePayment() {
  alert("ধন্যবাদ! দান করার জন্য QR কোড স্ক্যান করুন অথবা ম্যানুয়ালি পেমেন্ট করুন।");
}
